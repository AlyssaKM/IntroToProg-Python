'''
Create new program that asks the user for the name of a household item,
and then asks for its estimated value. (This project is similar to the last one!)

Ask the user for new entries and stores them in the 2-dimensional Tuple.

Ask the user, when the program exits, if they would like to save/add
the data to a text file called, HomeInventory.txt.
'''

tplTable = ()  #generate empty tuple table

while (True):  #take user input and store as a tuple in tuple table, with repeating loop
    tplRow = (input('Enter the item name: '),)
    tplRow += (input("Enter the item's estimated value: "),)
    tplTable += (tplRow,)
    strContinue = input('Would you like to enter another item? (Y/N) ')
    if strContinue.lower() == 'n': break

#offer user the option to save data to a text file
strSave = input('Would you like to store this data to the text file HomeInventory.txt? (Y/N) ')
if strSave.lower() == 'y':
    objDataFile = open("C:\\_PythonClass\\Module04\\HomeInventory.txt", "a")
    for row in tplTable:
        objDataFile.write(str(row) + "\n")
    objDataFile.close()
