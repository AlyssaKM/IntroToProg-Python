# -------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   AlyssaMatthews, 11/4/2017, Added code to complete assignment 6
# -------------------------------------------------#

# --Data-- #
# lstTable - a table for storing a to-do list (arranged in dictionary rows)
# strNewTask - string for storing a user's task input
# strNewPriority - string for storing user's priority input
# strRemoveTask - string for storing user input to remove a task


# --Processing-- #
class ToDoFunctions(object):
    '''This class contains the functions needed to manage the to-do list'''

    @staticmethod
    def load_data(filepath):
        '''Loads data from a file into the list [table]'''
        table = []
        objFile = open(filepath, "r")
        for line in objFile:
            strData = line.split(",")
            dicRow = {"task": (strData[0]).strip(), "priority": (strData[1]).strip()}
            table.append(dicRow)
        objFile.close()
        return table

    @staticmethod
    def show_list(showitems):
        '''Displays list items to the user'''
        for dicRow in showitems:
            print(dicRow["task"] + "," + dicRow["priority"])
        return

    @staticmethod
    def add_item(newitem, newpriority, table):
        '''Add an item to a 2-dimensional list'''
        dicRow = {"task": newitem.title(), "priority": newpriority.lower()}
        table.append(dicRow)
        return table

    @staticmethod
    def remove_item(lookfor, table):
        '''Removes an item from the to-do list'''
        boolTaskFound = False
        if len(table):
            for dicRow in table:
                if lookfor.title() in dicRow["task"]:
                    table.remove(dicRow)
                    boolTaskFound = True
                    print("The task", lookfor.title(), "has been removed")
        if not boolTaskFound:
            print("Task not found")
        return table

    @staticmethod
    def save_data(table, filepath):
        '''Saves the to-do list to a data file'''
        objFile = open(filepath, "w")
        if len(table):
            for dicRow in table:
                objFile.write(dicRow["task"] + "," + dicRow["priority"] + "\n")
            print("Data saved")
        else:
            print("No entries found")
        objFile.close()
        return


# --Presentation-- #

# Step 1 - Load data from a file
lstTable = ToDoFunctions.load_data("C:\\_PythonClass\\Module06\\ToDo.txt")

# Step 2 - Display a menu of choices to the user
while (True):
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item
    3) Remove an existing item
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    print()  # adding a new line

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        ToDoFunctions.show_list(lstTable)
        continue

    # Step 4 - Add a new item to the list/Table
    elif (strChoice.strip() == '2'):
        strNewTask = input("Enter a task: ")
        strNewPriority = input("Enter the task's priority: ")
        lstTable = ToDoFunctions.add_item(strNewTask, strNewPriority, lstTable)
        continue

    # Step 5 - Remove a new item from the list/Table
    elif (strChoice == '3'):
        strRemoveTask = input("Enter the task you wish to remove: ")
        lstTable = ToDoFunctions.remove_item(strRemoveTask, lstTable)
        continue

    # Step 6 - Save tasks to the file
    elif (strChoice == '4'):
        ToDoFunctions.save_data(lstTable, "C:\\_PythonClass\\Module06\\ToDo.txt")
        continue

    # Exit the program
    elif (strChoice == '5'):
        break

    else:
        print("Please enter a valid selection")
        continue
